<?php
echo 'Site 222223333333<br />';
phpinfo();